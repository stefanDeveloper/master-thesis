# OpenSSH Fingerprint Cowrie

This repository is part of the master thesis "Honeypot Implementation in a Cloud Environment".

# Getting Started

```sh
./configure
make
make install
```

Run Cowrie:

```sh
docker run -p 65522:2222 cowrie/cowrie:latest
```

Run Debian Buster and Jessie as comparison test:

```sh
docker build -f Dockerfile.jessie -t debian:jessie .
docker build -f Dockerfile.buster -t debian:buster .

docker run -p 65523:22 debian:jessie
docker run -p 65524:22 debian:buster
```

Connect to Debian and Cowrie:

```sh
ssh -p 65522 localhost
ssh -p 65523 localhost
ssh -p 65524 localhost
```

A packet length error will be received when connecting to Cowrie.
